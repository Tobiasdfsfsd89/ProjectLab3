#Library GUI Client Side
from tkinter import *
from tkinter import filedialog

import serial
import sqlite3

#serial connection functions
serialObject = serial.Serial()
serialObject.baudrate = 9600
serialObject.port = 'COM9'




#global variable that will contain file
file_data = None


def addRecord():
    global file_data
    a_data = author_entry.get()
    t_data = title_entry.get()

    #database setup
    connection = sqlite3.connect('LibraryRecords.db')
    cursor = connection.cursor()

    error = False
    if(len(a_data)<1):
        author_entry.config(bg='firebrick1')
        error=True

    if(len(t_data)<1):
        title_entry.config(bg='firebrick1')
        error=True
    if(file_data==None):
        add_file_btn.config(bg='firebrick1')
        #data_entry.config(bg='firebrick1')

        error=True
    if(error==False):
        author_entry.config(bg='white')
        title_entry.config(bg='white')
        add_file_btn.config(bg='white')
        #data_entry.config(bg='white')
        indicator_lbl.config(text="")
        
        cursor.execute("INSERT INTO records VALUES (?,?,?)",(a_data,t_data,file_data))
        connection.commit() #actually commiting changes
        connection.close()

    else:
        indicator_lbl.config(text="Error!")

    print((a_data,t_data,file_data))
    return

def removeRecord():
    a_data = author_entry.get()
    t_data = title_entry.get()

    #database setup
    connection = sqlite3.connect('LibraryRecords.db')
    cursor = connection.cursor()

    error = False
    if(len(a_data)<1):
        author_entry.config(bg='firebrick1')
        error=True

    if(len(t_data)<1):
        title_entry.config(bg='firebrick1')
        error=True

    if(error==False):
        author_entry.config(bg='white')
        title_entry.config(bg='white')
        #data_entry.config(bg='white')
        print("Deleting...")
        cursor.execute("DELETE from records WHERE oid=PLACEHOLDER")
        #cursor.execute("DELET")
        
        connection.commit()
        connection.close()

def updateView():
    #database setup
    connection = sqlite3.connect('LibraryRecords.db')
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM records")
    st = cursor.fetchall()
    for item in st:
        print("Author: " + item[0] + " | " + "Title: " + item[1])

    connection.close()

def addFile():
    global file_data
    #put the selected file into a variable
    file_data = filedialog.askopenfile(mode="r")
    file_data=file_data.read()
    print(file_data)

def quitProgram():
    if(serialObject.isOpen()):
        print("Closing Connection...")
    print("Quitting")
    root.quit()


root = Tk()
root.title("IR Library")
root.geometry("800x500")
root.config(background='tan')

#Entry boxes
author_entry = Entry(root,width=20)
author_entry.grid(row = 0,column = 1)
title_entry = Entry(root,width=20)
title_entry.grid(row = 1,column = 1)
#data_entry = Entry(root,width=20)
#data_entry.grid(row = 2,column = 1)

#Labels
author_lbl = Label(root,text = "Author",width=8,borderwidth=1,font=('Helvetica', 10, 'bold'),bg='tan',fg='black')
author_lbl.grid(row=0,column=0,pady=5)
title_lbl = Label(root,text = "Title",width=8,borderwidth=1,font=('Helvetica', 10, 'bold'),bg='tan',fg='black')
title_lbl.grid(row=1,column=0,pady=5)
data_lbl = Label(root,text = "Data",width=8,borderwidth=1,font=('Helvetica', 10, 'bold'),bg='tan',fg='black')
data_lbl.grid(row=2,column=0,pady=5)

#Indicator Label
indicator_lbl = Label(root,text = "",width=8,borderwidth=1,font=('Helvetica', 10, 'bold'),bg='tan',fg='black')
indicator_lbl.grid(row=3,column=2,padx=5,pady=5,ipadx=5)




#Buttons
add_entry = Button(root,text="Add Entry to Database",command=addRecord,borderwidth=1,relief=SOLID)
add_entry.grid(row=3,column=0,padx=5,pady=5,ipadx=10)
add_entry = Button(root,text="Remove Entry from Database",command=removeRecord,borderwidth=1,relief=SOLID)
add_entry.grid(row=3,column=1,padx=5,pady=5,ipadx=10)
add_entry = Button(root,text="View Entries In Database",command=updateView,borderwidth=1,relief=SOLID)
add_entry.grid(row=3,column=2,padx=5,pady=5,ipadx=10)

#more advanced file
add_file_btn = Button(root,text="Add File",command=addFile,borderwidth=1,relief=SOLID)
add_file_btn.grid(row=2,column=0,padx=5,pady=5,ipadx=10)


#Record Viewing Area

book_view = Text(root,height=15)
book_view.grid(row=4,column=0,padx=5,pady=5,columnspan=3)


connection = sqlite3.connect('LibraryRecords.db')
cursor = connection.cursor()

# #Creating a Table for the Database Initially
# cursor.execute("""
#      CREATE TABLE records(
#          Author text,
#          Title text,
#          Data blob
#      )""")


# connection.commit() #actually commiting changes
# connection.close()


root.mainloop()


