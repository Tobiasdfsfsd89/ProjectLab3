#Library GUI Client Side
from tkinter import *
from tkinter import filedialog

import sqlite3




#global variable that will contain file
file_data = None
#global variable that contains the result from query
query_results = None
#Global variable that tracks position in query_results
place_i = 0



def addRecord(author_e,title_e,file_btn):
    global file_data
    a_data = author_e.get()
    t_data = title_e.get()

    #database setup
    connection = sqlite3.connect('LibraryRecords.db')
    cursor = connection.cursor()

    error = False
    if(len(a_data)<1):
        author_e.config(bg='firebrick1')
        error=True

    if(len(t_data)<1):
        title_e.config(bg='firebrick1')
        error=True
    if(file_data==None):
        file_btn.config(bg='firebrick1')
        #data_entry.config(bg='firebrick1')

        error=True
    if(error==False):
        author_e.config(bg='white')
        title_e.config(bg='white')
        file_btn.config(bg='white')
        #data_entry.config(bg='white')
        indicator_lbl.config(text="")
        
        cursor.execute("INSERT INTO records VALUES (?,?,?)",(a_data,t_data,file_data))
        connection.commit() #actually commiting changes
        connection.close()

    else:
        indicator_lbl.config(text="Error!")

    print((a_data,t_data,file_data))
    return

def removeRecord(author_e,title_e):
    a_data = author_e.get()
    t_data = title_e.get()
    print(f"Deleting Record WHERE Author is {a_data} and Title is {t_data}")
    #database setup
    connection = sqlite3.connect('LibraryRecords.db')
    cursor = connection.cursor()
    error = False
    if(len(a_data)<1):
        author_e.config(bg='firebrick1')
        error=True
    if(len(t_data)<1):
        title_e.config(bg='firebrick1')
        error=True
    if(error==False):
        author_e.config(bg='white')
        title_e.config(bg='white')
        #data_entry.config(bg='white')
        print("Deleting...")
        cursor.execute("DELETE from records WHERE Author = (?) AND Title = (?)",(a_data,t_data))
        #cursor.execute("DELET")
        connection.commit()
        connection.close()
        

def updateView():
    global query_results
    #database setup
    connection = sqlite3.connect('LibraryRecords.db')
    cursor = connection.cursor()
    cursor.execute("SELECT *,rowid FROM records")
    query_results = cursor.fetchall()
    for item in query_results:
        print("Author: " + item[0] + " | " + "Title: " + item[1])
    #Populate record view with first item in the database
    forward_btn.config(state=NORMAL)
    back_btn.config(state=NORMAL)

    if(len(record_title_entry.get())<1 or len(record_author_entry.get())<1):
        record_title_entry.config(state=NORMAL)
        record_author_entry.config(state=NORMAL)
        record_data_entry.config(state=NORMAL)


        record_title_entry.insert('0',query_results[0][1])
        record_author_entry.insert('0',query_results[0][0])
        record_data_entry.insert('1.0',query_results[0][2])

        tmp_rowid =len(query_results[0])-1 
        primary_key.config(text=str(query_results[0][tmp_rowid]))

        record_title_entry.config(state=DISABLED)
        record_author_entry.config(state=DISABLED)

    connection.close()
    
def record_view_forward():
    global query_results
    global place_i
    if(place_i>=len(query_results)-1):
        print("OUT OF BOUNDS!!!!!!!!")
    else:
        place_i=place_i+1
        
        primary_key.config(text=str(query_results[place_i][3]))
        record_title_entry.config(state=NORMAL)
        record_author_entry.config(state=NORMAL)
        record_data_entry.config(state=NORMAL)
        record_title_entry.delete('0',END)
        record_author_entry.delete('0',END)
        record_data_entry.delete('1.0',END)

        record_title_entry.insert('0',query_results[place_i][1])
        record_author_entry.insert('0',query_results[place_i][0])
        record_data_entry.insert('1.0',query_results[place_i][2])

        record_title_entry.config(state=DISABLED)
        record_author_entry.config(state=DISABLED)


def record_view_backward():
    global query_results
    global place_i

    if(place_i<=0):
        print("OUT OF BOUNDS!!!!!!!!")
    else:
    #database setup
        place_i=place_i-1
        primary_key.config(text=str(query_results[place_i][3]))



        record_title_entry.config(state=NORMAL)
        record_author_entry.config(state=NORMAL)
        record_data_entry.config(state=NORMAL)

        record_title_entry.delete('0',END)
        record_author_entry.delete('0',END)
        record_data_entry.delete('1.0',END)


        record_title_entry.insert('0',query_results[place_i][1])
        record_author_entry.insert('0',query_results[place_i][0])
        record_data_entry.insert('1.0',query_results[place_i][2])


        record_title_entry.config(state=DISABLED)
        record_author_entry.config(state=DISABLED)

def addFile():
    global file_data
    #put the selected file into a variable
    file_data = filedialog.askopenfile(mode="r")
    file_data=file_data.read()
    #print(file_data)

def disconnect():
    print()

def addRecordWindow():

    top = Toplevel()
    top.geometry("300x300")
    #Add Record Window
    #--------------------------


    
    #Entry boxes
    author_entry = Entry(top,width=20)
    author_entry.grid(row = 0,column = 1)
    title_entry = Entry(top,width=20)
    title_entry.grid(row = 1,column = 1)

    #database labels

    author_lbl = Label(top,text = "Author",width=8,borderwidth=1,font=('Helvetica', 10, 'bold'),bg='tan',fg='black')
    author_lbl.grid(row=0,column=0,pady=5)
    title_lbl = Label(top,text = "Title",width=8,borderwidth=1,font=('Helvetica', 10, 'bold'),bg='tan',fg='black')
    title_lbl.grid(row=1,column=0,pady=5)
    data_lbl = Label(top,text = "Data",width=8,borderwidth=1,font=('Helvetica', 10, 'bold'),bg='tan',fg='black')
    data_lbl.grid(row=2,column=0,pady=5)
    #Choose File to be Uploaded
    add_file_btn = Button(top,text="Add File",command=addFile,borderwidth=1,relief=SOLID)
    add_file_btn.grid(row=2,column=1,padx=5,pady=5,ipadx=10)
    
    #Buttons
    add_record = Button(top,text="ADD",command=lambda: addRecord(author_entry,title_entry,add_file_btn),borderwidth=1,relief=SOLID)
    add_record.grid(row=1,column=2,padx=5,pady=5,ipadx=10)

def removeRecordWindow():

    top2 = Toplevel()
    top2.geometry("300x300")
    #Add Record Window
    #--------------------------
    #Entry boxes
    author_entry = Entry(top2,width=20)
    author_entry.grid(row = 0,column = 1)
    title_entry = Entry(top2,width=20)
    title_entry.grid(row = 1,column = 1)

    #labels
    author_lbl = Label(top2,text = "Author",width=8,borderwidth=1,font=('Helvetica', 10, 'bold'),bg='tan',fg='black')
    author_lbl.grid(row=0,column=0,pady=5)
    title_lbl = Label(top2,text = "Title",width=8,borderwidth=1,font=('Helvetica', 10, 'bold'),bg='tan',fg='black')
    title_lbl.grid(row=1,column=0,pady=5)

    #Buttons
    add_record = Button(top2,text="DELETE",command=lambda: removeRecord(author_entry,title_entry),borderwidth=1,relief=SOLID,fg='red')
    add_record.grid(row=1,column=2,padx=5,pady=5,ipadx=10)
    

def command_vw():
    database_view.grid_forget()
    patron_view.grid_forget()
    command_view.grid(row=1,column=0)
def database_vw():
    command_view.grid_forget()
    patron_view.grid_forget()
    database_view.grid(row=1,column=0)

def patron_vw():
    database_view.grid_forget()
    command_view.grid_forget()
    patron_view.grid(row=1,column=0)
def show_data():
    if(check_var.get()==True):
        record_data_entry.grid(row=4,column=1,pady=10,padx=10)
    else:
        record_data_entry.grid_forget()




root = Tk()
root.title("IR Library")
root.geometry("800x800")
root.config(background='tan')


database_view = LabelFrame(root,text = "Database View",background='tan',width=800,height=600)
database_view.grid(row=1,column=0)

#===========================================================================================================
#                   DATABASE VIEW UI ELEMENTS
#===========================================================================================================

#Indicator Label
indicator_lbl = Label(database_view,text = "",width=8,borderwidth=1,font=('Helvetica', 10, 'bold'),bg='tan',fg='black')
indicator_lbl.grid(row=0,column=2,padx=5,pady=5,ipadx=5)




add_entry = Button(database_view,text="Add Entry to Database",command=addRecordWindow)
add_entry.grid(row=0,column=0,padx=5,pady=5,ipadx=10)
remove_entry = Button(database_view,text="Remove Entry from Database",command=removeRecordWindow)
remove_entry.grid(row=0,column=1,padx=5,pady=5,ipadx=10)
view_entry = Button(database_view,text="Refresh",command=updateView)
view_entry.grid(row=0,column=2,padx=5,pady=5,ipadx=10)


#Record View UI Elements

record_title = Label(database_view,text = "Record Title: ")
record_title.grid(row=2,column=0,ipadx=7)
record_author = Label(database_view,text = "Record Author: ")
record_author.grid(row=3,column=0)
record_data = Label(database_view,text = "Record Data: ")
record_data.grid(row=4,column=0)

record_title_entry = Entry(database_view,bg='white',state=DISABLED)
record_title_entry.grid(row=2,column=1,ipadx=50)
record_author_entry = Entry(database_view,bg='white',state=DISABLED)
record_author_entry.grid(row=3,column=1,ipadx=50)
record_data_entry = Text(database_view,bg = 'white',width=50,height=20,state=DISABLED)

check_var = IntVar()
show_data_check = Checkbutton(database_view,command=show_data,text='Show Data',variable=check_var)
show_data_check.grid(row=3,column=2)


primary_key = Label(database_view,font=('Helvetica', 10, 'bold'),bg='white',fg='red',text='key')
primary_key.grid(row=2,column=2,ipadx=20)


forward_btn = Button(database_view,text = "Next",command= record_view_forward,state=DISABLED)
forward_btn.grid(row=5,column=1)
back_btn = Button(database_view,text = "Prev",command=record_view_backward,state=DISABLED)
back_btn.grid(row=5,column=0)


#===========================================================================================================
#===========================================================================================================


#===========================================================================================================
#                   MENU VIEW UI ELEMENTS
#===========================================================================================================
menu_frame = LabelFrame(root,text="Menu")
menu_frame.grid(row=0,column=0,sticky=NW)

command_vw_btn = Button(menu_frame,text="Command View",command = command_vw)
command_vw_btn.grid(row=0,column=0)

database_vw_btn = Button(menu_frame,text="Database View",command = database_vw)
database_vw_btn.grid(row=0,column=1)

patron_vw_btn = Button(menu_frame,text="Patron View",command = patron_vw)
patron_vw_btn.grid(row=0,column=2)


#===========================================================================================================
#                   COMMAND VIEW UI ELEMENTS
#===========================================================================================================
command_view = LabelFrame(root,text = "Command View",background="tan",width=800,height=600)
incoming_cmd_label= Label(command_view,text="Incoming Commands")
incoming_cmd_label.grid(row=0,column=0)
incoming_commands = Text(command_view,width=50,height=20)
incoming_commands.grid(row=1,column=0)

#===========================================================================================================


#===========================================================================================================
#                   PATRON VIEW UI ELEMENTS
#===========================================================================================================
patron_view  = LabelFrame(root,text = "Patron View",background="tan")

#===========================================================================================================

# #Creating a Table for the Database Initially
# cursor.execute("""
#      CREATE TABLE records(
#          Author text,
#          Title text,
#          Data blob
#      )""")


# connection.commit() #actually commiting changes
# connection.close()


root.mainloop()


