#Library GUI Client Side
from tkinter import *
import serial
import time

#serial connection functions
serialObject = serial.Serial()
serialObject.baudrate = 9600
serialObject.port = 'COM9'

#CONSTANTS
ACTIVATION_CODE = 3334
TEST_CARD = 1001

#GLOBALS

#functions
def addRequest():
    selectedItemTuple = bookList.curselection()
    #print(selectedItemTuple)
    
    if(len(selectedItemTuple)>0):
        #print(bookList.get(selectedItemTuple[0]))
        selectedItem = bookList.get(selectedItemTuple[0])
        bookRequest.insert(0,selectedItem)
        requestBooksButton.config(state=ACTIVE)
def sendRequest():
    if(serialObject.is_open==False):
        print("ERROR: WAIT FOR CONNECTION TO BE ESTABLISHED")
    else:

        sendCommand = str(ACTIVATION_CODE) + str(TEST_CARD) #join the two numbers as a string and convert to integer
        #for i in range(0,bookRequest.size()):
        #    print(bookRequest.get(i)) 
        serialObject.write(sendCommand.encode())
        time.sleep(1)
        readItem = serialObject.read_all()
        informationText.insert('1.0',readItem)


def quitProgram():
    if(serialObject.isOpen()):
        print("Closing Connection...")
    print("Quitting")
    root.quit()

def refreshBookList():
    for i in demo_books:
        bookList.insert(0,i)

#serialObject.isOpen
def connectServer():
    serialObject.open()
    if(serialObject.is_open):
        bookAdd.config(state = ACTIVE)
    
def view_books():
    print("Hi")

#def commandView():
    

demo_books = ["Beowulf","Great Expectations","Tom Sawyer"]
cardID = 123

root = Tk()
root.title("IR Library")
root.geometry("800x500")
root.config(background='white')

#menu bar
menuBarFrame = LabelFrame(root)
menuBarFrame.grid(row=0,column=0,columnspan=4,pady=10)
view_btn = Button(menuBarFrame,text = "View",command = view_books)
view_btn.grid(row=0,column=0)


#book selection UI
bookSelectionFrame = LabelFrame(root,text = "Book Selection",padx = 10, pady = 10)
bookSelectionFrame.grid(row=1,column=0)

selLab = Label(bookSelectionFrame, text="Select Books",padx=10,pady=10)
selLab.grid(row=0,column=0)

bookList = Listbox(bookSelectionFrame)
bookList.grid(row=1,column=0)


bookAdd = Button(bookSelectionFrame, text = "Add",command = addRequest,state=DISABLED)
bookAdd.grid(row=2,column=0)

bookRefreshButton = Button(bookSelectionFrame, text = "Refresh",command = refreshBookList)
bookRefreshButton.grid(row=3,column=0)

#book request UI
bookRequestFrame = LabelFrame(root,text = "Book Request",padx = 10, pady = 15)
bookRequestFrame.grid(row=1,column=1,ipady=15)

reqLab = Label(bookRequestFrame, text="Request Books",padx=5,pady=5)
reqLab.grid(row=0,column=1)

bookRequest = Listbox(bookRequestFrame)
bookRequest.grid(row=1,column=1)

requestBooksButton = Button(bookRequestFrame, text = "Send Request", command = sendRequest,state=DISABLED)
requestBooksButton.grid(row = 2,column = 1)

#quit
miscFrame = LabelFrame(root,text = "Other",padx = 10, pady = 10)
miscFrame.grid(row=2,column = 0,columnspan=3)
exitButton = Button(miscFrame, text = "Quit",command = quitProgram)
exitButton.grid(row = 0, column = 0)

informationText = Text(miscFrame,width=50,height=10)
informationText.grid(row = 0,column = 1)

#connect Button
connectButton = Button(miscFrame,text = "Connect",command = connectServer)
connectButton.grid(row=1,column=0)


root.mainloop()



