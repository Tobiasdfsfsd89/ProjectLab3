import serial

def start_server():
#serial connection functions
    serialObject = serial.Serial()
    serialObject.baudrate = 9600
    serialObject.port = 'COM9'



