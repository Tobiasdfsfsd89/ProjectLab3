import serial
import threading
import time


serialObject = serial.Serial()
serialObject.baudrate = 9600
serialObject.port = 'COM9'


#serverThread = threading.thread

def start_server():
#serial connection functions
    serialObject.open()
def read_data():
    # print("in Read Data")
    data = serialObject.read_until(expected="END".encode())
    print(data)
    return(data)
    
def listen_loop():
    close_flag = False
    while(close_flag==False):
        command = receive_command().decode()
        print("COMMAND = " + command)
        if(command=="SENDC"):
            # print("SENDING")
            data = read_data()
            print("DATA: " + data.decode())
        elif(command=="CLOSE"):
            print("CLOSING LOOP")
            close_flag=True

def receive_command():
    inputCommand = serialObject.read(5)
    print(inputCommand)
    return(inputCommand)

start_server()
listen_loop()
# for i in range(0,25):
    # print(receive_command())




