def fileRead(file):
    return
f = open("C:\\Users\\t1m0t\\Documents\\GitHub Repositories\\irlibrarysoftware\\irLibrarySoftware\\Hello world.pdf","rb")
print("hello")
data = f.read()
print(data)