#Library GUI Client Side
from tkinter import *
from tkinter import filedialog

import sqlite3
import threading
# import ServerCommandParser





#global variable that will contain file
file_data = None
#global variable that contains the result from query
query_results = None
#Global variable that tracks position in query_results
place_i = 0


#def guiServerInterface(code):
#    if code == 0:
#        ServerCommandParser.start_server()
#    elif code == 1:
        

def addRecord(author_e,title_e,file_btn,mode):
    global file_data
    a_data = author_e.get()
    t_data = title_e.get()

    #database setup
    if(mode==0):
        connection = sqlite3.connect('LibraryRecords.db')
        cursor = connection.cursor()
    elif(mode==1):
        connection = sqlite3.connect('UserRecords.db')
        cursor = connection.cursor()
    else:
        print("ERROR: INVALID MODE")
        
    error = False
    if(len(a_data)<1):
        author_e.config(bg='firebrick1')
        error=True

    if(len(t_data)<1):
        title_e.config(bg='firebrick1')
        error=True
    if(file_data==None and mode==0):
        file_btn.config(bg='firebrick1')
        #data_entry.config(bg='firebrick1')

    if(error==False):
        author_e.config(bg='white')
        title_e.config(bg='white')
        if(mode==0):
            file_btn.config(bg='white')
        #data_entry.config(bg='white')
        indicator_lbl.config(text="")
        
        if(mode==0):
            cursor.execute("INSERT INTO records VALUES (?,?,?)",(a_data,t_data,file_data))

        elif(mode==1):
            cursor.execute("INSERT INTO users VALUES (?,?)",(a_data,t_data))
        else:
            print("ERROR: INVALID MODE")

    else:
        indicator_lbl.config(text="Error!")
    connection.commit() #actually commiting changes
    connection.close()
    print((a_data,t_data,file_data))
    return

def removeRecord(argument1,argument2,mode):
    a_data = argument1.get()
    t_data = argument2.get()
    print(f"Deleting Record WHERE Author is {a_data} and Title is {t_data}")
    #database setup
    if(mode==0):
        connection = sqlite3.connect('LibraryRecords.db')
    elif(mode==1):
        connection = sqlite3.connect('UserRecords.db')
    else:
        print("Error: invalid mode!")
        return
    cursor = connection.cursor()
    error = False
    if(len(a_data)<1):
        argument1.config(bg='firebrick1')
        error=True
    if(len(t_data)<1):
        argument2.config(bg='firebrick1')
        error=True
    if(error==False):
        argument1.config(bg='white')
        argument2.config(bg='white')
        #data_entry.config(bg='white')
        if(mode==0):
            cursor.execute("DELETE from records WHERE Author = (?) AND Title = (?)",(a_data,t_data))
        else:
            cursor.execute("DELETE from users WHERE Username = (?) AND CardID = (?)",(a_data,t_data))

        #cursor.execute("DELET")
        connection.commit()
        connection.close()


def updateView(mode):
    global query_results
    #database setup
    if(mode==0):
        connection = sqlite3.connect('LibraryRecords.db')
        cursor = connection.cursor()
        cursor.execute("SELECT *,rowid FROM records")
        query_results = cursor.fetchall()
    if(mode==1):
        connection = sqlite3.connect('UserRecords.db')
        cursor = connection.cursor()
        cursor.execute("SELECT *,rowid FROM users")
        query_results = cursor.fetchall()
    for item in query_results:
        print(item)
    forward_btn.config(state=NORMAL)
    back_btn.config(state=NORMAL)
    # if(len(record_title_entry.get())<1 or len(record_author_entry.get())<1): #UNNEEDED IF STATEMENT?
    if(mode==0):
        record_title_entry.config(state=NORMAL)
        record_author_entry.config(state=NORMAL)
        record_data_entry.config(state=NORMAL)


        record_title_entry.insert('0',query_results[0][1])
        record_author_entry.insert('0',query_results[0][0])
        record_data_entry.insert('1.0',query_results[0][2])

        tmp_rowid =len(query_results[0])-1 
        primary_key.config(text=str(query_results[0][tmp_rowid]))

        record_title_entry.config(state=DISABLED)
        record_author_entry.config(state=DISABLED)
        record_data_entry.config(state=DISABLED)

    elif(mode==1):
        username_entry.config(state=NORMAL)
        cardID_entry.config(state=NORMAL)

        username_entry.insert('0',query_results[0][0])
        cardID_entry.insert('0',query_results[0][1])

        tmp_rowid =len(query_results[0])-1 
        primary_keyP.config(text=str(query_results[0][tmp_rowid]))


    connection.close()
    
def record_view_forward():
    global query_results
    global place_i
    if(place_i>=len(query_results)-1):
        print("OUT OF BOUNDS!!!!!!!!")
    else:
        place_i=place_i+1
        
        primary_key.config(text=str(query_results[place_i][3]))
        record_title_entry.config(state=NORMAL)
        record_author_entry.config(state=NORMAL)
        record_data_entry.config(state=NORMAL)
        record_title_entry.delete('0',END)
        record_author_entry.delete('0',END)
        record_data_entry.delete('1.0',END)

        record_title_entry.insert('0',query_results[place_i][1])
        record_author_entry.insert('0',query_results[place_i][0])
        record_data_entry.insert('1.0',query_results[place_i][2])

        record_title_entry.config(state=DISABLED)
        record_author_entry.config(state=DISABLED)


def record_view_backward():
    global query_results
    global place_i

    if(place_i<=0):
        print("OUT OF BOUNDS!!!!!!!!")
    else:
    #database setup
        place_i=place_i-1
        primary_key.config(text=str(query_results[place_i][3]))



        record_title_entry.config(state=NORMAL)
        record_author_entry.config(state=NORMAL)
        record_data_entry.config(state=NORMAL)

        record_title_entry.delete('0',END)
        record_author_entry.delete('0',END)
        record_data_entry.delete('1.0',END)


        record_title_entry.insert('0',query_results[place_i][1])
        record_author_entry.insert('0',query_results[place_i][0])
        record_data_entry.insert('1.0',query_results[place_i][2])


        record_title_entry.config(state=DISABLED)
        record_author_entry.config(state=DISABLED)
        record_data_entry.config(state=DISABLED)


def addFile():
    global file_data
    #put the selected file into a variable
    file_data = filedialog.askopenfile(mode="r")
    file_data=file_data.read()
    #print(file_data)

def disconnect():
    print()

def addRecordWindow(mode):

    top = Toplevel()
    top.geometry("300x300")
    #Add Record Window
    #--------------------------


    if(mode==0):
        #Entry boxes
        author_entry = Entry(top,width=20)
        author_entry.grid(row = 0,column = 1)
        title_entry = Entry(top,width=20)
        title_entry.grid(row = 1,column = 1)

        #database labels

        author_lbl = Label(top,text = "Author",width=8,borderwidth=1,font=('Helvetica', 10, 'bold'),bg='tan',fg='black')
        author_lbl.grid(row=0,column=0,pady=5)
        title_lbl = Label(top,text = "Title",width=8,borderwidth=1,font=('Helvetica', 10, 'bold'),bg='tan',fg='black')
        title_lbl.grid(row=1,column=0,pady=5)
        data_lbl = Label(top,text = "Data",width=8,borderwidth=1,font=('Helvetica', 10, 'bold'),bg='tan',fg='black')
        data_lbl.grid(row=2,column=0,pady=5)
        #Choose File to be Uploaded
        add_file_btn = Button(top,text="Add File",command=addFile,borderwidth=1,relief=SOLID)
        add_file_btn.grid(row=2,column=1,padx=5,pady=5,ipadx=10)
    
        #Buttons
        add_record = Button(top,text="ADD",command=lambda: addRecord(author_entry,title_entry,add_file_btn,0),borderwidth=1,relief=SOLID)
        add_record.grid(row=1,column=2,padx=5,pady=5,ipadx=10)
    elif mode==1:
        username_lbl = Label(top,text="Username",width=8,borderwidth=1,font=('Helvetica', 10, 'bold'),bg='tan',fg='black')
        username_lbl.grid(row=0,column=0,pady=5)
        cardID_lbl = Label(top,text="Card ID",width=8,borderwidth=1,font=('Helvetica', 10, 'bold'),bg='tan',fg='black')
        cardID_lbl.grid(row=1,column=0,pady=5)

        username_entry = Entry(top,width=20)
        username_entry.grid(row = 0,column = 1)
        cardID_entry = Entry(top,width=20)
        cardID_entry.grid(row = 1,column = 1)

        add_record = Button(top,text="ADD",command=lambda: addRecord(username_entry,cardID_entry,0,1),borderwidth=1,relief=SOLID)
        add_record.grid(row=1,column=2,padx=5,pady=5,ipadx=10)
def removeRecordWindow(mode):

    top2 = Toplevel()
    top2.geometry("300x300")

    if(mode==0):
        #remove Record Window
        #--------------------------
        #Entry boxes
        author_entry = Entry(top2,width=20)
        author_entry.grid(row = 0,column = 1)
        title_entry = Entry(top2,width=20)
        title_entry.grid(row = 1,column = 1)

        #labels
        author_lbl = Label(top2,text = "Author",width=8,borderwidth=1,font=('Helvetica', 10, 'bold'),bg='tan',fg='black')
        author_lbl.grid(row=0,column=0,pady=5)
        title_lbl = Label(top2,text = "Title",width=8,borderwidth=1,font=('Helvetica', 10, 'bold'),bg='tan',fg='black')
        title_lbl.grid(row=1,column=0,pady=5)

        #Buttons
        add_record = Button(top2,text="DELETE",command=lambda: removeRecord(author_entry,title_entry,mode),borderwidth=1,relief=SOLID,fg='red')
        add_record.grid(row=1,column=2,padx=5,pady=5,ipadx=10)
    elif(mode==1):
            #remove Record Window
        #--------------------------
        #Entry boxes
        username_entry = Entry(top2,width=20)
        username_entry.grid(row = 0,column = 1)
        title_entry = Entry(top2,width=20)
        title_entry.grid(row = 1,column = 1)

        #labels
        username_lbl = Label(top2,text = "Username",width=8,borderwidth=1,font=('Helvetica', 10, 'bold'),bg='tan',fg='black')
        username_lbl.grid(row=0,column=0,pady=5)
        title_lbl = Label(top2,text = "Card ID",width=8,borderwidth=1,font=('Helvetica', 10, 'bold'),bg='tan',fg='black')
        title_lbl.grid(row=1,column=0,pady=5)

        #Buttons
        add_record = Button(top2,text="DELETE",command=lambda: removeRecord(username_entry,title_entry,mode),borderwidth=1,relief=SOLID,fg='red')
        add_record.grid(row=1,column=2,padx=5,pady=5,ipadx=10)
    

def command_vw():
    database_view.grid_forget()
    patron_view.grid_forget()
    command_view.grid(row=1,column=0)
def database_vw():
    command_view.grid_forget()
    patron_view.grid_forget()
    database_view.grid(row=1,column=0)

def patron_vw():
    database_view.grid_forget()
    command_view.grid_forget()
    patron_view.grid(row=1,column=0)
def show_data():
    if(check_var.get()==True):
        record_data_entry.grid(row=4,column=1,pady=10,padx=10)
    else:
        record_data_entry.grid_forget()




root = Tk()
root.title("IR Library")
root.geometry("800x800")
root.config(background='tan')


database_view = LabelFrame(root,text = "Database View",background='tan',width=800,height=600)
database_view.grid(row=1,column=0)

#===========================================================================================================
#                   DATABASE VIEW UI ELEMENTS
#===========================================================================================================

#Indicator Label
indicator_lbl = Label(database_view,text = "",width=8,borderwidth=1,font=('Helvetica', 10, 'bold'),bg='tan',fg='black')
indicator_lbl.grid(row=0,column=2,padx=5,pady=5,ipadx=5)




add_entry = Button(database_view,text="Add Entry to Database",command=lambda: addRecordWindow(0))
add_entry.grid(row=0,column=0,padx=5,pady=5,ipadx=10)
remove_entry = Button(database_view,text="Remove Entry from Database",command=lambda: removeRecordWindow(0))
remove_entry.grid(row=0,column=1,padx=5,pady=5,ipadx=10)
view_entry = Button(database_view,text="Refresh",command=lambda: updateView(0))
view_entry.grid(row=0,column=2,padx=5,pady=5,ipadx=10)


#Record View UI Elements

record_title = Label(database_view,text = "Record Title: ")
record_title.grid(row=2,column=0,ipadx=7)
record_author = Label(database_view,text = "Record Author: ")
record_author.grid(row=3,column=0)
record_data = Label(database_view,text = "Record Data: ")
record_data.grid(row=4,column=0)

record_title_entry = Entry(database_view,bg='white',state=DISABLED)
record_title_entry.grid(row=2,column=1,ipadx=50)
record_author_entry = Entry(database_view,bg='white',state=DISABLED)
record_author_entry.grid(row=3,column=1,ipadx=50)
record_data_entry = Text(database_view,bg = 'white',width=50,height=20,state=DISABLED)

check_var = IntVar()
show_data_check = Checkbutton(database_view,command=show_data,text='Show Data',variable=check_var)
show_data_check.grid(row=3,column=2)


primary_key = Label(database_view,font=('Helvetica', 10, 'bold'),bg='white',fg='red',text='key')
primary_key.grid(row=2,column=2,ipadx=20)


forward_btn = Button(database_view,text = "Next",command= record_view_forward,state=DISABLED)
forward_btn.grid(row=5,column=1)
back_btn = Button(database_view,text = "Prev",command=record_view_backward,state=DISABLED)
back_btn.grid(row=5,column=0)


#===========================================================================================================
#===========================================================================================================


#===========================================================================================================
#                   MENU VIEW UI ELEMENTS
#===========================================================================================================
menu_frame = LabelFrame(root,text="Menu")
menu_frame.grid(row=0,column=0,sticky=NW)

command_vw_btn = Button(menu_frame,text="Command View",command = command_vw)
command_vw_btn.grid(row=0,column=0)

database_vw_btn = Button(menu_frame,text="Database View",command = database_vw)
database_vw_btn.grid(row=0,column=1)

patron_vw_btn = Button(menu_frame,text="Patron View",command = patron_vw)
patron_vw_btn.grid(row=0,column=2)


#===========================================================================================================
#                   COMMAND VIEW UI ELEMENTS
#===========================================================================================================
command_view = LabelFrame(root,text = "Command View",background="tan",width=800,height=600)
incoming_cmd_label= Label(command_view,text="Incoming Commands")
incoming_cmd_label.grid(row=0,column=0)
incoming_commands = Text(command_view,width=50,height=20)
incoming_commands.grid(row=1,column=0)

testButton = Button(command_view,text="Send Test")
testButton.grid(row=2,column=0)


#===========================================================================================================


#===========================================================================================================
#                   PATRON VIEW UI ELEMENTS
#===========================================================================================================
patron_view  = LabelFrame(root,text = "Patron View",background="tan")
add_entry = Button(patron_view,text="Add Entry to Database",command=lambda: addRecordWindow(1))
add_entry.grid(row=0,column=0,padx=5,pady=5,ipadx=10)
remove_entry = Button(patron_view,text="Remove Entry from Database",command=lambda: removeRecordWindow(1))
remove_entry.grid(row=0,column=1,padx=5,pady=5,ipadx=10)
view_entry = Button(patron_view,text="Refresh",command=lambda: updateView(1))
view_entry.grid(row=0,column=2,padx=5,pady=5,ipadx=10)

username_lbl = Label(patron_view,text="Username",borderwidth=1,font=('Helvetica', 10, 'bold'),bg='tan',fg='black')
username_lbl.grid(row=1,column=0)
username_entry = Entry(patron_view,state=DISABLED)
username_entry.grid(row=1,column=1)

cardID_lbl = Label(patron_view,text="CardID",borderwidth=1,font=('Helvetica', 10, 'bold'),bg='tan',fg='black')
cardID_lbl.grid(row=2,column=0)
cardID_entry = Entry(patron_view,state=DISABLED)
cardID_entry.grid(row=2,column=1)

primary_keyP = Label(patron_view,font=('Helvetica', 10, 'bold'),bg='white',fg='red',text='key')
primary_keyP.grid(row=2,column=2,ipadx=20)
'''

#Record View UI Elements

record_title = Label(database_view,text = "Record Title: ")
record_title.grid(row=2,column=0,ipadx=7)
record_author = Label(database_view,text = "Record Author: ")
record_author.grid(row=3,column=0)
record_data = Label(database_view,text = "Record Data: ")
record_data.grid(row=4,column=0)

record_title_entry = Entry(database_view,bg='white',state=DISABLED)
record_title_entry.grid(row=2,column=1,ipadx=50)
record_author_entry = Entry(database_view,bg='white',state=DISABLED)
record_author_entry.grid(row=3,column=1,ipadx=50)
record_data_entry = Text(database_view,bg = 'white',width=50,height=20,state=DISABLED)

check_var = IntVar()
show_data_check = Checkbutton(database_view,command=show_data,text='Show Data',variable=check_var)
show_data_check.grid(row=3,column=2)


primary_key = Label(database_view,font=('Helvetica', 10, 'bold'),bg='white',fg='red',text='key')
primary_key.grid(row=2,column=2,ipadx=20)


forward_btn = Button(database_view,text = "Next",command= record_view_forward,state=DISABLED)
forward_btn.grid(row=5,column=1)
back_btn = Button(database_view,text = "Prev",command=record_view_backward,state=DISABLED)
back_btn.grid(row=5,column=0)




#===========================================================================================================
'''
# #Creating a Table for the Database Initially
#connection = sqlite3.connect('UserRecords.db')
#cursor = connection.cursor()
#cursor.execute("""
#      CREATE TABLE users(
#          Username text,
#          CardID integer
#      )""")


# connection.commit() #actually commiting changes
# connection.close()


root.mainloop()


